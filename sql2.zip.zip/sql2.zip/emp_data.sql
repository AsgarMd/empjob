/*
SQLyog Ultimate v8.55 
MySQL - 5.1.36-community-log 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `emp_data` (
	`Emp_Id` double ,
	`Emp_Name` varchar (150),
	`Email_Id` varchar (150),
	`Mobile_No` varchar (33),
	`Join_date` date ,
	`Job` varchar (150),
	`Gender` varchar (30),
	`token` varchar (33),
	`status` varchar (30)
); 
insert into `emp_data` (`Emp_Id`, `Emp_Name`, `Email_Id`, `Mobile_No`, `Join_date`, `Job`, `Gender`, `token`, `status`) values('1001','Asgar Ansari','mdasgar@gmail.com','9874563210','2021-06-20','web developer','male',NULL,NULL);
insert into `emp_data` (`Emp_Id`, `Emp_Name`, `Email_Id`, `Mobile_No`, `Join_date`, `Job`, `Gender`, `token`, `status`) values('1002','Manish Kumar','manish@gmail.com','7631526598','2021-06-25','Web Developer','male',NULL,NULL);
insert into `emp_data` (`Emp_Id`, `Emp_Name`, `Email_Id`, `Mobile_No`, `Join_date`, `Job`, `Gender`, `token`, `status`) values('1003','rahul kumar','rahul@gmail.com','9865741230','2021-06-30','Graphics Designer','male',NULL,NULL);
insert into `emp_data` (`Emp_Id`, `Emp_Name`, `Email_Id`, `Mobile_No`, `Join_date`, `Job`, `Gender`, `token`, `status`) values('1004','surbhi kumari','surbhi@gmail.com','9994561230','2021-07-12','Web Designer','female',NULL,NULL);
