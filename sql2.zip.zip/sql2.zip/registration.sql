/*
SQLyog Ultimate v8.55 
MySQL - 5.1.36-community-log 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `registration` (
	`ID` double ,
	`username` varchar (150),
	`email` varchar (150),
	`mobile` varchar (33),
	`password` varchar (150),
	`cpassword` varchar (150),
	`token` varchar (150),
	`status` varchar (60)
); 
insert into `registration` (`ID`, `username`, `email`, `mobile`, `password`, `cpassword`, `token`, `status`) values('1001','Asgar Ansari','asgar@gmail.com','9654785278','1234','1234',NULL,NULL);
insert into `registration` (`ID`, `username`, `email`, `mobile`, `password`, `cpassword`, `token`, `status`) values('1002','monu','monu@gmail.com','09865412730','monu@123','monu@123',NULL,NULL);
insert into `registration` (`ID`, `username`, `email`, `mobile`, `password`, `cpassword`, `token`, `status`) values('1003','manish','manish@gmail.com','8765432123','1234','1234',NULL,NULL);
insert into `registration` (`ID`, `username`, `email`, `mobile`, `password`, `cpassword`, `token`, `status`) values('1004','amit kumar','amit@gmail.com','9865745632','amit@123','amit@123',NULL,NULL);
insert into `registration` (`ID`, `username`, `email`, `mobile`, `password`, `cpassword`, `token`, `status`) values('1005','vinay kumar','vinay@gmail.com','7894561230','vinay123','vinay123',NULL,NULL);
insert into `registration` (`ID`, `username`, `email`, `mobile`, `password`, `cpassword`, `token`, `status`) values('1006','raju kumar','raju@gmail.com','7894563210','raju1234','raju1234',NULL,NULL);
