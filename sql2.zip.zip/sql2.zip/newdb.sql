/*
SQLyog Ultimate v8.55 
MySQL - 5.1.36-community-log : Database - sign_up
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`sign_up` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `sign_up`;

/*Table structure for table `emp_data` */

DROP TABLE IF EXISTS `emp_data`;

CREATE TABLE `emp_data` (
  `Emp_Id` int(50) DEFAULT NULL,
  `Emp_Name` char(50) DEFAULT NULL,
  `Email_Id` varchar(50) DEFAULT NULL,
  `Mobile_No` varchar(11) DEFAULT NULL,
  `Join_date` date DEFAULT NULL,
  `Job` char(50) DEFAULT NULL,
  `Gender` char(10) DEFAULT NULL,
  `token` varchar(11) DEFAULT NULL,
  `status` char(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `emp_data` */

insert  into `emp_data`(`Emp_Id`,`Emp_Name`,`Email_Id`,`Mobile_No`,`Join_date`,`Job`,`Gender`,`token`,`status`) values (1001,'Asgar Ansari','mdasgar@gmail.com','9874563210','2021-06-20','web developer','male',NULL,NULL),(1002,'Manish Kumar','manish@gmail.com','7631526598','2021-06-25','Web Developer','male',NULL,NULL),(1003,'rahul kumar','rahul@gmail.com','9865741230','2021-06-30','Graphics Designer','male',NULL,NULL),(1004,'surbhi kumari','surbhi@gmail.com','9994561230','2021-07-12','Web Designer','female',NULL,NULL);

/*Table structure for table `registration` */

DROP TABLE IF EXISTS `registration`;

CREATE TABLE `registration` (
  `ID` int(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `password` varchar(50) NOT NULL,
  `cpassword` varchar(50) NOT NULL,
  `token` varchar(50) DEFAULT NULL,
  `status` char(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1007 DEFAULT CHARSET=latin1;

/*Data for the table `registration` */

insert  into `registration`(`ID`,`username`,`email`,`mobile`,`password`,`cpassword`,`token`,`status`) values (1001,'Asgar Ansari','asgar@gmail.com','9654785278','1234','1234',NULL,NULL),(1002,'monu','monu@gmail.com','09865412730','monu@123','monu@123',NULL,NULL),(1003,'manish','manish@gmail.com','8765432123','1234','1234',NULL,NULL),(1004,'amit kumar','amit@gmail.com','9865745632','amit@123','amit@123',NULL,NULL),(1005,'vinay kumar','vinay@gmail.com','7894561230','vinay123','vinay123',NULL,NULL),(1006,'raju kumar','raju@gmail.com','7894563210','raju1234','raju1234',NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
